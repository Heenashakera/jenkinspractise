document.addEventListener('DOMContentLoaded', () => {
    console.log('Document loaded');
});
